#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
root=$1; m=socks5-awg-udp
rows=()
# ABBA, then BAAB: four repetitions per direction on identical settings.
for delay in 100 0; do for dir in up down; do
 for pair in reference:101 final:101 final:211 reference:211 final:307 reference:307 reference:419 final:419; do
   IFS=: read -r b s <<<"$pair"; arm=auto; if [[ $b == reference ]];then arm=shim;fi
   rows+=("$b:$arm:$m:$delay:0:$s:8:0:$dir")
 done
done; done
for n in 1 8;do for seed in 101 211;do for dir in down up;do rows+=("final:auto:$m:100:1:$seed:$n:0:$dir");done;done;done
# Carriers: matched transport, offer load, direction and underlay; no carrier modifications.
for mode in socks5-awg-ext-tcp socks5-awg-req-tcp socks5-awg-ext-utp socks5-awg-req-utp; do
 for loss in 0 1;do for dir in up down;do
   rows+=("reference:shim:$mode:100:$loss:101:1:0:$dir" "final:auto:$mode:100:$loss:101:1:0:$dir")
 done;done
done
./run-profile.sh certified "${rows[*]}"
LAB_UP_LOSS=0 ./run-profile.sh oneside "final:auto:$m:100:1:211:1:0:down"
LAB_DOWN_LOSS=0 ./run-profile.sh oneside "final:auto:$m:100:1:101:8:0:up"
./run-profile.sh bottleneck "final:auto:$m:100:1:101:8:10:down"
if [[ -e transition.log ]];then mv transition.log transition-previous.log;fi
mkdir -p current
ln -sfn "$PWD/final/btawg-server" current/btawg-server; ln -sfn "$PWD/final/btawg-client" current/btawg-client
LAB_REUSE_BINARIES=1 LAB_RUNS='auto:2:101:8:0:down' bash transition.sh "$root"
python3 -I transition-reduce.py transition.log | cut -f1-13,23-28,33-34
