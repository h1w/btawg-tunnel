# Sourced inside native.sh for the final transparent-AWG profile suite.
# Environment expected from the runner:
#   LAB_ARM, LAB_LOSS, LAB_SEED, LAB_FLOWS, LAB_RATE, LAB_DIRECTION
#   LAB_DELAY_MS (default 100), LAB_OFFLOADS (selective)

set -euo pipefail

if [[ $LAB_RATE == 10 && ${LAB_DIRECTION:-down} != down ]]; then
  printf 'Shared downlink rate=10 is only supported for direction=down\n' >&2
  exit 2
fi

loss_opts() {
  local delay=${LAB_DELAY_MS:-100}ms
  opts=(limit 262144 delay "$delay")
  if [[ $2 == 1 ]]; then opts+=(loss random 1% seed "$1"); fi
}

turn_off_tcp() {
  PYTHONPATH="$BIN" python3 - "$1" <<'PY'
import sys
from importlib import import_module
with import_module('offload-loss').Ethtool(sys.argv[1]) as eth:
    problems = eth.enforce_off(('tx-tcp-segmentation', 'tx-tcp-ecn-segmentation',
                                'tx-tcp-mangleid-segmentation', 'tx-tcp6-segmentation', 'rx-gro'))
    if problems:
        raise RuntimeError(problems)
PY
}

turn_off_tcp hub0
export -f turn_off_tcp
export BIN
cli bash -ec 'turn_off_tcp cli0'
wan bash -ec 'turn_off_tcp tohub; turn_off_tcp downloss'
fifo bash -ec 'turn_off_tcp fromwan; turn_off_tcp tocli'

loss_opts "$((LAB_SEED+1000))" "${LAB_DOWN_LOSS:-$LAB_LOSS}"
wan tc qdisc replace dev downloss root netem "${opts[@]}"
loss_opts "$LAB_SEED" "${LAB_UP_LOSS:-$LAB_LOSS}"
wan tc qdisc replace dev tohub root netem "${opts[@]}"
printf '{"down":%d,"up":%d}\n' "${LAB_DOWN_LOSS:-$LAB_LOSS}" "${LAB_UP_LOSS:-$LAB_LOSS}" > raw/profile.json

if [[ $LAB_RATE == 10 ]]; then
  fifo tc qdisc replace dev tocli root handle 1: tbf rate 10mbit burst 8kb limit 32000
  fifo tc qdisc replace dev tocli parent 1:1 handle 10: bfifo limit 32000
  active=direct,tunnel
else
  active=tunnel
fi

if [[ $LAB_ARM == tcp ]]; then active=direct; fi

# Start the AWG client if this run uses the tunnel.
if [[ $active == *tunnel* ]]; then
  case $LAB_ARM in
    shim) repair=0;;
    reserve) repair=1;;
    wide) repair=wide;;
    coded) repair=coded;;
    auto) repair=auto;;
    *) exit 2;;
  esac
  nsenter -t "$child" -n -- env BTAWG_AWG_REPAIR="$repair" "${client_command[@]}" "$LAB_BINARY_DIR/btawg-client" -config client.txt -transport "${LAB_TRANSPORT:-socks5-awg-udp}" >client.log 2>&1 & client=$!
  for ((i=0;i<15;i++)); do
    if cli ip -4 addr show dev btawg0 2>/dev/null | grep -q 'inet '; then break; fi
    kill -0 "$client"
    [[ $i != 14 ]]
    sleep .2
  done
  # Capture the assigned client VPN IP now that the tunnel is up.
  client_ip=$(cli ip -brief -4 address show dev btawg0 | awk '{print $3}' | cut -d/ -f1)
  [[ -n "$client_ip" ]]
  printf 'CLIENT_IP %s\n' "$client_ip" >>raw/stages.txt
  export LAB_CLIENT_IP="$client_ip"
fi

# MTU verification for the tunnel direction under test (plus the reverse).
verify_mtu() {
  local src_ns=$1 dst_ip=$2 label=$3
  if [[ $src_ns == cli ]]; then
    cli ping -n -M do -s 1252 -c 3 -I btawg0 "$dst_ip" >"raw/mtu-${label}.ping" 2>&1
  else
    ping -n -M do -s 1252 -c 3 -I btawg0 "$dst_ip" >"raw/mtu-${label}.ping" 2>&1
  fi
  if grep -qiE 'frag needed|too long|packet too big' "raw/mtu-${label}.ping"; then
    printf 'MTU %s FAILED\n' "$label" >&2
    cat "raw/mtu-${label}.ping" >&2
    exit 1
  fi
  printf 'MTU %s OK\n' "$label" >>raw/stages.txt
}

if [[ $active == *tunnel* ]]; then
  ip -j link show btawg0 | jq -e '.[0].mtu==1280' >/dev/null
  cli ip -j link show btawg0 | jq -e '.[0].mtu==1280' >/dev/null
fi

snapshot() {
  wan tc -s -j qdisc show dev downloss >"raw/loss-down-$1.json"
  wan tc -s -j qdisc show dev tohub >"raw/loss-up-$1.json"
  fifo tc -s -j qdisc show dev tocli >"raw/fifo-$1.json"
  curl -fs -m 3 -b cookies "$base/api/traffic" > traffic.json
  jq -e '.engine_queue_drops' traffic.json >"raw/engine-$1.json"
  jq -e '.awg_recovery' traffic.json >"raw/recovery-$1.json"
  cat /proc/net/snmp >"raw/hub-net-$1"
  cli cat /proc/net/snmp >"raw/client-net-$1"
  if [[ -e /sys/class/net/btawg0 ]]; then
    ip -s -j link show dev btawg0 >"raw/tun-hub-$1.json"
  else
    echo '[]' >"raw/tun-hub-$1.json"
  fi
  if cli test -e /sys/class/net/btawg0; then
    cli ip -s -j link show dev btawg0 >"raw/tun-client-$1.json"
  else
    echo '[]' >"raw/tun-client-$1.json"
  fi
}
if [[ ${LAB_WIRE_CHECK:-0} == 1 ]]; then
  python3 "$BIN/wirecheck.py" hub0 wire-ready >raw/wire.json & captureHub=$!
  for ((i=0;i<100;i++)); do [[ ! -e wire-ready ]] || break; kill -0 "$captureHub"; sleep .02; done
  test -e wire-ready
fi
snapshot before
# Start loss schedule for transition tests (no-op if LAB_LOSS_SCHEDULE is empty).
export LAB_TRANSIT_PID="$transit" LAB_CHILD_PID="$child" LAB_LIMITER_PID="$limiter"
bash "$BIN/loss_schedule.sh" & loss_sched=$!

# Dedicated per-namespace samplers capture the physical bytes/packets offered
# at hub0 and cli0 exactly over the receiver's measurement window.  They open
# /proc/net/dev fresh for each snapshot in the proper namespace and reject
# samples whose read time drifts more than 50 ms from the receiver's window
# stamps (window-begin at the WARMUP sample, window-end at WARMUP+WINDOW).
phy_sampler() {
  python3 - "$1" "$2" <<'PY'
import json, sys, time
from pathlib import Path

iface, out = sys.argv[1:3]
start_path = Path('window-begin')
done_path = Path('window-end')
out_path = Path(out)

def read_dev():
    # /proc/net/dev is a synthetic file: a freshly opened fd is required for
    # each snapshot or the kernel returns the previous view.
    with open('/proc/net/dev', 'rb') as fd:
        for raw in fd:
            line = raw.decode('utf-8', errors='replace')
            if not line.strip() or iface not in line:
                continue
            parts = line.split()
            if parts[0].rstrip(':') != iface:
                continue
            return {
                'rx_bytes': int(parts[1]),
                'rx_packets': int(parts[2]),
                'rx_dropped': int(parts[4]),
                'tx_bytes': int(parts[9]),
                'tx_packets': int(parts[10]),
                'tx_dropped': int(parts[12]),
            }
    raise RuntimeError(f'interface {iface} not found in /proc/net/dev')

def wait_and_read(path, deadline):
    while not path.exists():
        if time.monotonic() > deadline:
            raise TimeoutError(f'waiting for {path}')
        time.sleep(0.005)
    stamp_ns = int(path.read_text())
    now_ns = time.monotonic_ns()
    skew_ms = (now_ns - stamp_ns) / 1e6
    if skew_ms > 50:
        raise RuntimeError(f'{iface} physical sample skew {skew_ms:.1f}ms > 50ms')
    data = read_dev()
    data['stamp_ns'] = stamp_ns
    data['monotonic_ns'] = now_ns
    data['skew_ms'] = skew_ms
    return data

deadline = time.monotonic() + 65
begin = wait_and_read(start_path, deadline)
end = wait_and_read(done_path, deadline)

out_path.write_text(json.dumps({
    'iface': iface,
    'begin': begin,
    'end': end,
    'duration_s': (end['monotonic_ns'] - begin['monotonic_ns']) / 1e9,
}, separators=(',', ':')))
PY
}
export -f phy_sampler

phy_sampler hub0 raw/phy-hub.json & phy_hub=$!
cli bash -ec 'phy_sampler "$@"' bash cli0 raw/phy-client.json & phy_client=$!

ping -n -D -i .2 192.0.2.6 >raw/underlay.ping & underlay_ping=$!

# Start senders in the namespace appropriate for the test direction.
if [[ $active == *direct* ]]; then
  "${perf_command[@]}" python3 "$BIN/final-traffic.py" send "${LAB_DIRECTION:-down}" direct 2>raw/direct.stderr & direct=$!
fi
if [[ $active == *tunnel* ]]; then
  if [[ ${LAB_DIRECTION:-down} == down ]]; then
    "${perf_command[@]}" python3 "$BIN/final-traffic.py" send down tunnel 2>raw/tunnel.stderr & iperf=$!
  else
    cli "${perf_command[@]}" python3 "$BIN/final-traffic.py" send up tunnel 2>raw/tunnel.stderr & iperf=$!
  fi
  (while [[ ! -e start ]]; do sleep .01; done; exec nsenter -t "$child" -n -- ping -n -D -I btawg0 -i .2 10.77.0.1) >raw/overlay.ping & overlay_ping=$!
fi

# The receiver always runs in the namespace that terminates the tunnel flow.
if [[ ${LAB_DIRECTION:-down} == down ]]; then
  cli timeout -k 2 65 "${perf_command[@]}" python3 "$BIN/final-traffic.py" receive down "$active" >raw/bytes.jsonl 2>raw/receive.stderr
else
  timeout -k 2 65 "${perf_command[@]}" python3 "$BIN/final-traffic.py" receive up "$active" >raw/bytes.jsonl 2>raw/receive.stderr
fi

if [[ -n ${direct:-} ]]; then wait "$direct"; direct=; fi
if [[ -n ${iperf:-} ]]; then wait "$iperf"; iperf=; fi

# The receiver has stamped 'done'; collect the physical samples before the
# post-run snapshot so a failed sampler aborts the CASE cleanly.
if [[ -n ${phy_hub:-} ]]; then wait "$phy_hub"; phy_hub=; fi
if [[ -n ${phy_client:-} ]]; then wait "$phy_client"; phy_client=; fi

snapshot after
if [[ ${LAB_WIRE_CHECK:-0} == 1 ]]; then
  kill "$captureHub"; wait "$captureHub"; captureHub=
  jq -e '.awg_udp > 0 and .legacy_clear_marker == 0 and .clear_inner_control == 0' raw/wire.json >/dev/null
fi
printf 'DONE\n'
