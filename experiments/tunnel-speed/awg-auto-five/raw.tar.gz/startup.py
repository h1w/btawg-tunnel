"""Receiver-side ramp for cold windows (1 s bins, not sender ACK throughput)."""
import csv,json,sys
from pathlib import Path

def read1(raw,name): return json.loads((raw/name).read_text())
out=csv.writer(sys.stdout,delimiter='\t',lineterminator='\n')
out.writerow('arm loss seed flows link direction run first_s_Mbps first_bin_end_gt50_s wire_payload_0_10 clamp_hub recovered_hub coded_pieces_hub auto_tx_on auto_rx_on bins_Mbps'.split())
for log in map(Path,sys.argv[1:]):
    for line in log.read_text().splitlines():
        if line.startswith('CASE '): case=line.split()[1:]
        elif line.startswith('ARTIFACTS '):run=Path(line.split()[1]).name;raw=log.parent/run/'raw'
        elif line=='DONE':
            samples=[json.loads(l) for l in (raw/'bytes.jsonl').read_text().splitlines()];assert [s['second'] for s in samples]==list(range(11));assert 'tunnel' in samples[0] and sum(samples[0]['tunnel'])==0
            bins=[(sum(b['tunnel'])-sum(a['tunnel']))*8000/(b['monotonic_ns']-a['monotonic_ns']) for a,b in zip(samples,samples[1:])]; first=next((i for i,v in enumerate(bins,1) if v>50),None)
            cost=sum((x['end']['tx_bytes']-x['begin']['tx_bytes']) for x in (read1(raw,f'phy-{side}.json') for side in ('hub','client')));useful=sum(sum(samples[-1][k])-sum(samples[0][k]) for k in ('tunnel','direct') if k in samples[0]);a,b=[read1(raw,f'recovery-{s}.json') for s in ('before','after')]
            out.writerow([*case,run,f'{bins[0]:.3f}',first or '-',f'{cost/useful:.3f}',*[b[k]-a[k] for k in ('window_clamps','recovered_packets','coded_pieces','auto_tx_on','auto_rx_on')],','.join(f'{v:.3f}' for v in bins)])
        elif line=='FAILED':out.writerow([*case,run,*(['-']*9)])
