#!/usr/bin/env python3
"""Continuous physical-interface byte sampler.

Usage:
    transition-phy.py <iface> <output.jsonl>

Samples /proc/net/dev for the given interface every 100 ms until the file
'done' appears in the current directory, then takes one final sample and exits.
"""
import json
import sys
import time
from pathlib import Path

iface, out = sys.argv[1:3]
done = Path('done')


def read_once(f, t):
    with open('/proc/net/dev', 'rb') as fd:
        for raw in fd:
            line = raw.decode('utf-8', errors='replace')
            if iface not in line:
                continue
            parts = line.split()
            if parts[0].rstrip(':') != iface:
                continue
            rec = {
                'monotonic_ns': t,
                'wall_ns': time.time_ns(),
                'rx_bytes': int(parts[1]),
                'rx_packets': int(parts[2]),
                'rx_dropped': int(parts[4]),
                'tx_bytes': int(parts[9]),
                'tx_packets': int(parts[10]),
                'tx_dropped': int(parts[12]),
            }
            f.write(json.dumps(rec) + '\n')
            f.flush()
            return


with open(out, 'w') as f:
    while True:
        t = time.monotonic_ns()
        read_once(f, t)
        if done.exists():
            time.sleep(0.02)
            read_once(f, time.monotonic_ns())
            break
        time.sleep(0.1)
