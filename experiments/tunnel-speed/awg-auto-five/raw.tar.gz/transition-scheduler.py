#!/usr/bin/env python3
"""Apply the clean -> 1%% loss -> clean transition from the transit namespace.

Uses `tc qdisc change` to avoid queue purge. Snapshots the qdisc before and
after each change and stamps actual monotonic/wall timestamps to a log file.

Environment:
  LAB_TRANSIT_PID   transit namespace PID (required)
  LAB_LIMITER_PID   limiter namespace PID (optional)
  LAB_DELAY_MS      netem delay (default 100)
  LAB_SEED          netem loss seed (default 101)
  LAB_PHASE_CLEAN1_S  initial clean phase seconds (default 12)
  LAB_PHASE_LOSS_S    loss phase seconds (default 32)
  LAB_PHASE_CLEAN2_S  final clean phase seconds (default 20)

Argument: output log path (e.g. raw/transition.log).
"""
import json
import os
import subprocess
import sys
import time
from pathlib import Path

transit_pid = os.environ.get('LAB_TRANSIT_PID', '')
limiter_pid = os.environ.get('LAB_LIMITER_PID', '')
if not transit_pid:
    print('transition-scheduler: LAB_TRANSIT_PID not set', file=sys.stderr)
    sys.exit(1)

delay_ms = int(os.environ.get('LAB_DELAY_MS', '100'))
seed = int(os.environ.get('LAB_SEED', '101'))
down_seed = seed + 1000
phase_clean1 = int(os.environ.get('LAB_PHASE_CLEAN1_S', '12'))
phase_loss = int(os.environ.get('LAB_PHASE_LOSS_S', '32'))
phase_clean2 = int(os.environ.get('LAB_PHASE_CLEAN2_S', '20'))

log_path = Path(sys.argv[1]) if len(sys.argv) > 1 else Path('raw/transition.log')
log_path.parent.mkdir(parents=True, exist_ok=True)


def nsenter(pid, cmd):
    return ['nsenter', '-t', pid, '-n', '--'] + cmd


def wan(cmd):
    return subprocess.run(nsenter(transit_pid, cmd), check=True, capture_output=True)


def fifo(cmd):
    pid = limiter_pid if limiter_pid else transit_pid
    return subprocess.run(nsenter(pid, cmd), check=True, capture_output=True)


def now():
    return {'monotonic_ns': time.monotonic_ns(), 'wall_ns': time.time_ns()}


def log(event, extra=None):
    rec = now()
    rec['event'] = event
    if extra:
        rec.update(extra)
    with open(log_path, 'a') as f:
        f.write(json.dumps(rec, separators=(',', ':')) + '\n')


def snapshot(label):
    down = json.loads(wan(['tc', '-s', '-j', 'qdisc', 'show', 'dev', 'downloss']).stdout)
    up = json.loads(wan(['tc', '-s', '-j', 'qdisc', 'show', 'dev', 'tohub']).stdout)
    fq = json.loads(fifo(['tc', '-s', '-j', 'qdisc', 'show', 'dev', 'tocli']).stdout)
    out_dir = log_path.parent
    (out_dir / f'loss-down-{label}.json').write_text(json.dumps(down, separators=(',', ':')))
    (out_dir / f'loss-up-{label}.json').write_text(json.dumps(up, separators=(',', ':')))
    (out_dir / f'fifo-{label}.json').write_text(json.dumps(fq, separators=(',', ':')))
    log('snapshot', {'label': label})


def apply_loss(loss_pct):
    cfg = {
        'loss_pct': loss_pct,
        'delay_ms': delay_ms,
        'down': {'dev': 'downloss', 'seed': down_seed},
        'up': {'dev': 'tohub', 'seed': seed},
    }
    if loss_pct == 0:
        wan(['tc', 'qdisc', 'change', 'dev', 'downloss', 'root', 'netem',
             'limit', '262144', 'delay', f'{delay_ms}ms'])
        wan(['tc', 'qdisc', 'change', 'dev', 'tohub', 'root', 'netem',
             'limit', '262144', 'delay', f'{delay_ms}ms'])
    else:
        wan(['tc', 'qdisc', 'change', 'dev', 'downloss', 'root', 'netem',
             'limit', '262144', 'delay', f'{delay_ms}ms',
             'loss', 'random', f'{loss_pct}%', 'seed', str(down_seed)])
        wan(['tc', 'qdisc', 'change', 'dev', 'tohub', 'root', 'netem',
             'limit', '262144', 'delay', f'{delay_ms}ms',
             'loss', 'random', f'{loss_pct}%', 'seed', str(seed)])
    validate_loss(loss_pct)
    return cfg


def validate_loss(expected_pct):
    for dev, expected, expected_seed in (('downloss', expected_pct, down_seed),
                                          ('tohub', expected_pct, seed)):
        out = wan(['tc', '-s', '-j', 'qdisc', 'show', 'dev', dev]).stdout
        qs = json.loads(out)
        q = next((q for q in qs if q.get('kind') == 'netem'), None)
        if q is None:
            raise RuntimeError(f'netem qdisc missing on {dev}')
        opts = q.get('options', {})
        actual_loss = opts.get('loss-random', {}).get('loss', 0) * 100
        actual_seed = opts.get('seed')
        actual_delay = opts.get('delay', {}).get('delay', 0)
        if actual_loss != expected:
            raise RuntimeError(f'{dev} loss mismatch: expected {expected}%, got {actual_loss}%')
        if expected_pct != 0 and actual_seed != expected_seed:
            raise RuntimeError(f'{dev} seed mismatch: expected {expected_seed}, got {actual_seed}')
        if abs(actual_delay - delay_ms / 1000) > 0.001:
            raise RuntimeError(f'{dev} delay mismatch: expected {delay_ms}ms, got {actual_delay*1000}ms')


def wait_for_file(path, timeout=120):
    path = Path(path)
    deadline = time.monotonic() + timeout
    while not path.exists():
        if time.monotonic() > deadline:
            raise TimeoutError(path)
        time.sleep(0.02)
    return int(path.read_text())


def spin_until(target_ns):
    while time.monotonic_ns() < target_ns:
        remain = (target_ns - time.monotonic_ns()) / 1e9
        if remain > 0.002:
            time.sleep(min(remain, 0.005))


def main():
    begin_ns = wait_for_file('window-begin')
    log('window_begin', {'window_begin_ns': begin_ns})

    t1 = begin_ns + phase_clean1 * 1_000_000_000
    spin_until(t1)
    snapshot('phase1_end')

    cfg = apply_loss(1)
    snapshot('to_loss')
    log('to_loss', cfg)

    t2 = begin_ns + (phase_clean1 + phase_loss) * 1_000_000_000
    spin_until(t2)
    snapshot('phase2_end')

    cfg = apply_loss(0)
    snapshot('to_clean')
    log('to_clean', cfg)

    t3 = begin_ns + (phase_clean1 + phase_loss + phase_clean2) * 1_000_000_000
    spin_until(t3)
    snapshot('phase3_end')


if __name__ == '__main__':
    main()
