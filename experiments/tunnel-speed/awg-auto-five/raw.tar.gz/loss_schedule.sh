#!/usr/bin/env bash
# Change netem loss mid-run using `tc qdisc change` (avoids purging the queue).
#
# Constant schedule mode (used by final-cases.sh):
#   LAB_LOSS_SCHEDULE="loss_pct:duration_sec,..."
#   Example: "0:4,1:20,0:6" = 0%% for 4s, 1%% for 20s, 0%% for 6s.
#
# The harness must export LAB_TRANSIT_PID (and optionally LAB_SEED/LAB_DELAY_MS).
set -euo pipefail

SCHEDULE="${LAB_LOSS_SCHEDULE:-}"
[[ -z "$SCHEDULE" ]] && exit 0

transit_pid=${LAB_TRANSIT_PID:-${transit:-}}
if [[ -z "${transit_pid:-}" ]]; then
  printf 'loss_schedule: LAB_TRANSIT_PID is not set\n' >&2
  exit 1
fi

wan() { nsenter -t "$transit_pid" -n -- "$@"; }

delay_ms=${LAB_DELAY_MS:-100}
seed=${LAB_SEED:-101}
down_seed=$((seed + 1000))

wait_for_qdisc() {
  local dev=$1
  local until_t=$(($(date +%s) + 15))
  while ! wan tc qdisc show dev "$dev" 2>/dev/null | grep -q netem; do
    if [[ $(date +%s) -ge $until_t ]]; then
      printf 'loss_schedule: timeout waiting for netem on %s\n' "$dev" >&2
      exit 1
    fi
    sleep 0.05
  done
}

validate_loss() {
  local dev=$1 expected=$2
  wait_for_qdisc "$dev"
  local opts
  opts=$(wan tc qdisc show dev "$dev" | head -1)
  if [[ "$expected" == "0" ]]; then
    if grep -qE 'loss[[:space:]]+random' <<<"$opts"; then
      printf 'loss_schedule: %s still has loss after change to clean: %s\n' "$dev" "$opts" >&2
      exit 1
    fi
  else
    if ! grep -qE "loss[[:space:]]+random[[:space:]]+${expected}%" <<<"$opts"; then
      printf 'loss_schedule: %s does not show expected %s%% loss: %s\n' "$dev" "$expected" "$opts" >&2
      exit 1
    fi
  fi
}

apply_loss() {
  local loss=$1
  wait_for_qdisc downloss
  wait_for_qdisc tohub
  if [[ "$loss" == "0" ]]; then
    wan tc qdisc change dev downloss root netem limit 262144 delay "${delay_ms}ms"
    wan tc qdisc change dev tohub root netem limit 262144 delay "${delay_ms}ms"
  else
    wan tc qdisc change dev downloss root netem limit 262144 delay "${delay_ms}ms" loss random "${loss}%" seed "$down_seed"
    wan tc qdisc change dev tohub root netem limit 262144 delay "${delay_ms}ms" loss random "${loss}%" seed "$seed"
  fi
  validate_loss downloss "$loss"
  validate_loss tohub "$loss"
}

IFS=',' read -ra PHASES <<< "$SCHEDULE"
for phase in "${PHASES[@]}"; do
  IFS=':' read -r loss dur <<< "$phase"
  apply_loss "$loss"
  sleep "$dur"
done
