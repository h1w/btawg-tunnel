#!/usr/bin/env bash
# AWG auto-repair transition profile runner.
#
# Usage:
#   ./transition.sh <path-to-matching-checkout>
#
# Builds (or reuses) the btawg client/server binaries, then executes the
# transition profile suite: constant clean baseline, constant 1%% loss baseline,
# and clean -> 1%% loss -> clean transition.  Output is appended to
# transition.log in this directory.
#
# Override the full profile list with LAB_RUNS as a whitespace-separated list of
#   arm:loss:seed:flows:rate:direction
# where loss is 0 (clean baseline), 1 (loss baseline), or 2 (transition).
#
# Tune phase durations with LAB_PHASE_CLEAN1_S, LAB_PHASE_LOSS_S,
# LAB_PHASE_CLEAN2_S (defaults 12/32/20).  Use LAB_TRANSITION_PROFILES to
# restrict generation: baseline, transition, or all (default).
set -euo pipefail
root=$(realpath "${1:?matching checkout}")
cd -- "$(dirname -- "$0")"
d=$PWD
export LC_ALL=C LAB_BINARY_DIR="$d/current" LAB_CASES="$d/transition-cases.sh" LAB_OFFLOADS=selective
export LAB_HUB_CORES=0-3 LAB_CLIENT_CORES=4-5 LAB_IPERF_CORES=6-7
export LAB_DELAY_MS=100
export LAB_WARMUP_S=2
export LAB_PHASE_CLEAN1_S=${LAB_PHASE_CLEAN1_S:-12}
export LAB_PHASE_LOSS_S=${LAB_PHASE_LOSS_S:-32}
export LAB_PHASE_CLEAN2_S=${LAB_PHASE_CLEAN2_S:-20}

if [[ ${LAB_REUSE_BINARIES:-0} != 1 ]]; then
  mkdir -p current build
  (cd "$root/btawg"; GOTMPDIR="$d/build" TMPDIR="$d/build" go build -o "$d/current/" ./cmd/btawg-client ./cmd/btawg-server)
fi
sha256sum current/{btawg-client,btawg-server} > transition-build.sha256

arm_order() {
  local arms="${LAB_ARMS:-shim reserve auto}"
  if [[ $1 == 101 ]]; then
    echo "$arms" | awk '{for(i=NF;i>0;i--) printf "%s ", $i}'
  else
    echo "$arms"
  fi
}

generate_profiles() {
  local mode="${LAB_TRANSITION_PROFILES:-all}"
  local losses=()
  case $mode in
    baseline) losses=(0 1) ;;
    transition) losses=(2) ;;
    all) losses=(0 1 2) ;;
    *) printf 'LAB_TRANSITION_PROFILES must be baseline, transition, or all\n' >&2; exit 2 ;;
  esac
  for loss in "${losses[@]}"; do
    if [[ $loss == 1 ]]; then seeds=(101 211); else seeds=(101); fi
    for seed in "${seeds[@]}"; do
      for flows in 1 8; do
        for arm in $(arm_order "$seed"); do
          for direction in down up; do
            echo "$arm:$loss:$seed:$flows:0:$direction"
          done
        done
      done
    done
  done
}

if [[ -n ${LAB_RUNS:-} ]]; then
  profiles=$LAB_RUNS
else
  profiles=$(generate_profiles)
fi

printf '# AWG transition profile suite started %s\n' "$(date -Iseconds)" >> transition.log
sha256sum current/{btawg-client,btawg-server} >> transition.log

for row in $profiles; do
  IFS=: read -r arm loss seed flows rate direction <<<"$row"
  printf 'CASE %s %s %s %s %s %s\n' "$arm" "$loss" "$seed" "$flows" "$rate" "$direction" | tee -a transition.log
  if ! LAB_ARM="$arm" LAB_LOSS="$loss" LAB_SEED="$seed" LAB_FLOWS="$flows" LAB_RATE="$rate" LAB_DIRECTION="$direction" unshare -Urn -- bash native.sh >> transition.log 2>&1; then
    printf 'FAILED\n' >> transition.log
  fi
done

printf '# AWG transition profile suite finished %s\n' "$(date -Iseconds)" >> transition.log
