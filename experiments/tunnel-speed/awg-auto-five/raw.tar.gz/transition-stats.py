#!/usr/bin/env python3
"""Poll hub /api/traffic at 4 Hz and append timestamped JSON lines.

Usage:
    transition-stats.py <base_url> <cookies_file> <output.jsonl>

Only the awg_recovery object (and optionally engine_queue_drops) is stored; no
client records or session identifiers are retained.
"""
import json
import subprocess
import sys
import time
from pathlib import Path

base_url = sys.argv[1].rstrip('/')
cookies_file = sys.argv[2]
out_path = Path(sys.argv[3])
out_path.parent.mkdir(parents=True, exist_ok=True)

done_path = Path('done')
interval = 0.25


def fetch():
    try:
        out = subprocess.run(
            ['curl', '-fs', '-m', '3', '-b', cookies_file, f'{base_url}/api/traffic'],
            check=True, capture_output=True, text=True,
        ).stdout
        data = json.loads(out)
        rec = {'awg_recovery': data.get('awg_recovery', {})}
        if 'engine_queue_drops' in data:
            rec['engine_queue_drops'] = data['engine_queue_drops']
        return rec
    except Exception as e:
        return {'error': str(e)}


with open(out_path, 'w') as f:
    while True:
        t0 = time.monotonic()
        data = fetch()
        rec = {
            'monotonic_ns': time.monotonic_ns(),
            'wall_ns': time.time_ns(),
            'data': data,
        }
        f.write(json.dumps(rec, separators=(',', ':')) + '\n')
        f.flush()
        if done_path.exists():
            # Capture the final boundary, then stop.
            time.sleep(0.02)
            rec = {
                'monotonic_ns': time.monotonic_ns(),
                'wall_ns': time.time_ns(),
                'data': fetch(),
            }
            f.write(json.dumps(rec, separators=(',', ':')) + '\n')
            f.flush()
            break
        elapsed = time.monotonic() - t0
        sleep_for = interval - elapsed
        if sleep_for > 0:
            time.sleep(sleep_for)
