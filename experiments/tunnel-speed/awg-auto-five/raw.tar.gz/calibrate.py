import collections
import socket
import struct
import sys
import time

address, mode = sys.argv[1:3]
endpoint = (address, 59123)
with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
    if mode == 'recv':
        sock.bind(endpoint)
        sock.settimeout(1)
        counts = collections.Counter()
        try:
            while True:
                counts[sock.recv(2000)[0]] += 1
        except TimeoutError:
            pass
        observed = collections.Counter(counts[i] for i in range(60))
        print(f'CALIBRATION deliveries per 32-datagram burst: {dict(sorted(observed.items()))}')
        assert len(counts) == 60 and 21 <= sum(counts.values())/60 <= 29 and len(observed) >= 4, observed
    else:
        sock.connect(endpoint)
        for i in range(60):
            sock.sendmsg([bytes([i])*32000], [(17, 103, struct.pack('H', 1000))])
            time.sleep(.002)
