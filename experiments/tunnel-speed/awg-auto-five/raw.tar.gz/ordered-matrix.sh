#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
rows=()
for m in socks5-awg-ext-tcp socks5-awg-req-tcp socks5-awg-ext-utp socks5-awg-req-utp;do for loss in 0 1;do for dir in up down;do rows+=("ordered:auto:$m:100:$loss:101:1:0:$dir"); done; done; done
for seed in 307 419;do rows+=("reference:shim:socks5-awg-req-tcp:100:0:$seed:1:0:down" "ordered:auto:socks5-awg-req-tcp:100:0:$seed:1:0:down");done
# Same native code path in this build; verify each actual shipping binary on LAN, WAN and loss.
for delay in 0 100; do for dir in down up;do rows+=("ordered:auto:socks5-awg-udp:$delay:0:101:8:0:$dir");done;done
for seed in 101 211;do for n in 1 8;do for dir in up down;do rows+=("ordered:auto:socks5-awg-udp:100:1:$seed:$n:0:$dir");done;done;done
./run-profile.sh rollout "${rows[*]}"
