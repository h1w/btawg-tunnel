import csv,sys,statistics as stats
from pathlib import Path
p=Path(sys.argv[1]);rows=list(csv.DictReader((p/'measurements.tsv').open(),delimiter='\t'))
def select(**kw):return [r for r in rows if all(r[k]==str(v) for k,v in kw.items())]
def rate(r):return float(r['tunnel_Mbps'])
print('Native clean ABBA; median Mbit/s and percent change:')
for delay in [0,100]:
 for direction in ['down','up']:
  v=select(series='certified',mode='socks5-awg-udp',loss=0,one_way_ms=delay,direction=direction); a,b=([rate(r) for r in v if r['build']==k] for k in ['reference','final']); assert len(a)==len(b)==4
  print(delay*2,direction,round(stats.median(a),2),round(stats.median(b),2),round((stats.median(b)/stats.median(a)-1)*100,2))
print('Lossy native simultaneous throughput, cost and RTT gates:')
v=select(series='certified',mode='socks5-awg-udp',loss=1);assert len(v)==8
for r in v:print(r['seed'],r['tunnel_flows'],r['direction'],r['tunnel_Mbps'],r['wire_ratio'],r['overlay_p95_ms'],r['status']=='ok' and rate(r)>50 and float(r['wire_ratio'])<=1.8 and float(r['overlay_p95_ms'])<=230)
print('Carrier end-to-end (one stream), clean down/up, lossy down/up Mbit/s:')
for m in sorted({r['mode'] for r in rows} - {'socks5-awg-udp'}):
 for build in ['reference','final']:
  v=select(series='certified',mode=m,build=build);assert len(v)==4
  print(m,build,*[next(r['tunnel_Mbps'] for r in v if r['direction']==d and r['loss']==str(l)) for l in [0,1] for d in ['down','up']])
print('All measured windows',len(rows),'with',sum(r['status']=='ok' for r in rows),'valid receiver windows')
