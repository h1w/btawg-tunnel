#!/usr/bin/env bash
set -euo pipefail
umask 077
BIN=$(cd -- "$(dirname -- "$0")" && pwd)
D=$(mktemp -d "$BIN/run.XXXXXXXX")
printf 'ARTIFACTS %s\n' "$D"
cd "$D"
for var in ${!BTAWG_@}; do unset "$var"; done
if [[ -n ${LAB_UTP_PACE:-} ]]; then export BTAWG_UTP_PACE_MBPS="$LAB_UTP_PACE"; fi
mkdir -p raw
child= transit= limiter= hub= client= iperf= probe= sampler=
captureHub= captureClient= progress= direct= underlay_ping= overlay_ping= shim_hub= shim_client= loss_sched=
cleanup() {
  for p in "${hub_stats:-}" "${phy_hub:-}" "${phy_client:-}" "$loss_sched" "$overlay_ping" "$underlay_ping" "$direct" "$progress" "$captureHub" "$captureClient" "$sampler" "$probe" "$client" "$iperf" "$shim_hub" "$shim_client" "$hub" "$transit" "$limiter" "$child"; do
    if [[ -n "$p" ]]; then kill "$p" 2>/dev/null || :; fi
  done
  wait || :
}
trap cleanup EXIT
trap 'exit 143' TERM
trap 'exit 130' INT
unshare -n -- sleep infinity & child=$!
unshare -n -- sleep infinity & transit=$!
unshare -n -- sleep infinity & limiter=$!
cli() { nsenter -t "$child" -n -- "$@"; }
wan() { nsenter -t "$transit" -n -- "$@"; }
fifo() { nsenter -t "$limiter" -n -- "$@"; }
for ns in "$child" "$transit" "$limiter"; do
  for ((i=0;i<100;i++)); do
    if [[ -e /proc/$ns/ns/net && $(readlink /proc/$ns/ns/net) != $(readlink /proc/self/ns/net) ]]; then break; fi
    sleep .02
  done
  [[ $(readlink /proc/$ns/ns/net) != $(readlink /proc/self/ns/net) ]]
done
ip link set lo up
cli ip link set lo up
# An intervening namespace applies netem after the sender NIC has split
# any UDP_SEGMENT super-packet. GRO stays off on all four veth interfaces.
ip link add hub0 type veth peer name tohub netns "$transit"
wan ip link add downloss type veth peer name fromwan netns "$limiter"
cli ip link add cli0 type veth peer name tocli netns "$limiter"
ip address add 192.0.2.1/30 dev hub0
wan ip address add 192.0.2.2/30 dev tohub
wan ip address add 192.0.2.9/30 dev downloss
fifo ip address add 192.0.2.10/30 dev fromwan
fifo ip address add 192.0.2.5/30 dev tocli
cli ip address add 192.0.2.6/30 dev cli0
hub_command=() client_command=() perf_command=()
if [[ -n ${LAB_HUB_CORES:-} ]]; then
  hub_command=(taskset -c "$LAB_HUB_CORES")
  client_command=(taskset -c "$LAB_CLIENT_CORES")
  perf_command=(taskset -c "$LAB_IPERF_CORES")
  printf 'CPU affinity hub=%s client=%s iperf=%s\n' "$LAB_HUB_CORES" "$LAB_CLIENT_CORES" "$LAB_IPERF_CORES"
fi
case ${LAB_OFFLOADS:-off} in
off)
  python3 "$BIN/offloads.py" hub0
  wan python3 "$BIN/offloads.py" tohub
  wan python3 "$BIN/offloads.py" tocli
  cli python3 "$BIN/offloads.py" cli0
  ;;
selective)
  python3 "$BIN/offload-loss.py" endpoint hub0
  wan python3 "$BIN/offload-loss.py" transit tohub downloss
  fifo python3 "$BIN/offload-loss.py" transit fromwan tocli
  cli python3 "$BIN/offload-loss.py" endpoint cli0
  ;;
on)
  [[ ${LAB_LOSS:-0} == 0 ]]
  printf 'OFFLOADS Linux defaults; loss disabled\n'
  ;;
*) exit 2 ;;
esac
ip link set hub0 up
wan ip link set tohub up
wan ip link set downloss up
fifo ip link set fromwan up
fifo ip link set tocli up
cli ip link set cli0 up
ip route add default via 192.0.2.2 dev hub0
cli ip route add default via 192.0.2.5 dev cli0
wan ip route add 192.0.2.4/30 via 192.0.2.10
fifo ip route add default via 192.0.2.9
fifo sysctl -w net.ipv4.ip_forward=1
wan sysctl -w net.ipv4.ip_forward=1
wan ip -4 route
sysctl -w net.ipv4.tcp_no_metrics_save=1
cli sysctl -w net.ipv4.tcp_no_metrics_save=1
if [[ ${LAB_OFFLOADS:-off} == selective ]]; then
  ping -n -q -c 2 -i .1 192.0.2.6 >/dev/null
  wan tc qdisc add dev downloss root netem loss 20%
  nsenter -t "$child" -n -- python3 "$BIN/calibrate.py" 192.0.2.6 recv & probe=$!
  sleep .15
  python3 "$BIN/calibrate.py" 192.0.2.6 send
  wait "$probe"; probe=
  wan tc qdisc del dev downloss root
  wan tc qdisc add dev tohub root netem loss 20%
  python3 "$BIN/calibrate.py" 192.0.2.1 recv & probe=$!
  sleep .15
  cli python3 "$BIN/calibrate.py" 192.0.2.1 send
  wait "$probe"; probe=
  wan tc qdisc del dev tohub root
fi
case ${LAB_ARM:-shim} in
  wide) export BTAWG_AWG_REPAIR=wide ;;
  coded) export BTAWG_AWG_REPAIR=coded ;;
  auto) export BTAWG_AWG_REPAIR=auto ;;
esac
"${hub_command[@]}" "${LAB_BINARY_DIR:-$BIN}/btawg-server" run -store lab.db -external-ip 192.0.2.1 -dht-bootstrap 127.0.0.1:1 >hub.log 2>&1 & hub=$!
ip -4 route
cli ip -4 route
base=http://127.0.0.1:8080
for ((i=0;i<100;i++)); do
  if curl -fs -m 1 "$base/login" >/dev/null; then break; fi
  if ! kill -0 "$hub"; then cat hub.log >&2; exit 1; fi
  sleep .05
done
password=$(awk '/panel login admin/ {print $6}' hub.log)
[[ -n "$password" ]]
curl -fs -m 5 -c cookies --data-urlencode username=admin --data-urlencode "password=$password" "$base/login" >/dev/null
csrf=$(curl -fs -m 5 -b cookies "$base/clients" | grep -o 'name="csrf" value="[^"]*"' | awk -F'"' 'NR==1 {print $4}')
import_path=$(curl -fs -m 5 -b cookies -o /dev/null -w '%{redirect_url}' --data-urlencode "csrf=$csrf" --data-urlencode name=local-benchmark "$base/clients/create")
[[ $import_path == "$base"/clients/import\?id=* ]]
curl -fs -m 5 -b cookies "$import_path" | python3 -c 'import html,re,sys; print(html.unescape(re.search(r"id=\"import-string\">([^<]+)",sys.stdin.read())[1]))' > client.txt
ip -brief -4 address show dev btawg0
source "${LAB_CASES:-$BIN/native-cases.sh}"
if [[ ${LAB_OBSERVE:-0} == 1 ]]; then
  kill "$hub"
  wait "$hub" || :
  hub=
  grep '^LAB ' hub.log | tee raw/stages.txt
fi
