#!/usr/bin/env python3
"""Reducer for the AWG transition profile suite.

Reads transition.log (or any log produced by transition.sh) and emits a TSV
with one row per completed CASE. Phase goodput and physical TX bytes are
computed over the steady 10 s window ending each phase.
"""
import csv
import json
import math
import re
import sys
from pathlib import Path

EXPECTED_DELAY_MS = 100
STEADY_S = 10

out = csv.writer(sys.stdout, delimiter='\t', lineterminator='\n')
out.writerow([
    'arm', 'loss', 'seed', 'flows', 'rate', 'direction', 'run', 'status', 'profile', 'window_s',
    'clean1_Mbps', 'loss_Mbps', 'clean2_Mbps',
    'clean1_hub_tx_bytes', 'loss_hub_tx_bytes', 'clean2_hub_tx_bytes',
    'clean1_cli_tx_bytes', 'loss_cli_tx_bytes', 'clean2_cli_tx_bytes',
    'clean1_payload_bytes', 'loss_payload_bytes', 'clean2_payload_bytes',
    'clean1_wire_ratio', 'loss_wire_ratio', 'clean2_wire_ratio',
    'clean1_overlay_p95_ms', 'loss_overlay_p95_ms', 'clean2_overlay_p95_ms',
    'loss_overlay_missing',
    'clean1_underlay_p95_ms', 'loss_underlay_p95_ms', 'clean2_underlay_p95_ms',
    'to_loss_latency_ms', 'to_clean_latency_ms',
    'down_loss_pct_phase1', 'down_loss_pct_phase2', 'down_loss_pct_phase3',
    'up_loss_pct_phase1','up_loss_pct_phase2','up_loss_pct_phase3',
])


def load_jsonl(path):
    if not path.exists():
        return []
    return [json.loads(line) for line in path.read_text().splitlines() if line.strip()]


def load_profile(raw):
    p = raw / 'profile.json'
    if p.exists():
        return json.loads(p.read_text())
    return {'loss_profile': 2, 'phase_clean1_s': 12, 'phase_loss_s': 32, 'phase_clean2_s': 20, 'warmup_s': 2}


def phase_windows_wall(profile, window_begin_wall_ns):
    c1 = profile['phase_clean1_s']
    lo = profile['phase_loss_s']
    c2 = profile['phase_clean2_s']
    wb = window_begin_wall_ns
    def win(end_offset):
        end = wb + end_offset * 1_000_000_000
        return (end - STEADY_S * 1_000_000_000, end)
    return {
        'clean1': win(c1),
        'loss': win(c1 + lo),
        'clean2': win(c1 + lo + c2),
    }


def single_window_wall(window_begin_wall_ns, total_window_s):
    end = window_begin_wall_ns + total_window_s * 1_000_000_000
    return {'clean1': (end - STEADY_S * 1_000_000_000, end),
            'loss': (end - STEADY_S * 1_000_000_000, end),
            'clean2': (end - STEADY_S * 1_000_000_000, end)}


def nearest(samples, ts):
    """Return sample with timestamp closest to ts."""
    assert samples
    best = samples[0]
    best_d = abs(best['wall_ns'] - ts)
    for s in samples[1:]:
        d = abs(s['wall_ns'] - ts)
        if d < best_d:
            best, best_d = s, d
    return best


def window_samples(samples, begin_ns, end_ns):
    """Return first and last sample nearest to the boundaries."""
    a = nearest(samples, begin_ns)
    b = nearest(samples, end_ns)
    skew_a_ms = abs(a['wall_ns'] - begin_ns) / 1e6
    skew_b_ms = abs(b['wall_ns'] - end_ns) / 1e6
    duration_s = (b['wall_ns'] - a['wall_ns']) / 1e9
    return a, b, skew_a_ms, skew_b_ms, duration_s


def goodput(bytes_jsonl, begin_ns, end_ns):
    if len(bytes_jsonl) < 2:
        return None
    a, b, sa, sb, dur = window_samples(bytes_jsonl, begin_ns, end_ns)
    assert sa <= 50 and sb <= 50, f'bytes sample skew {sa:.1f}ms / {sb:.1f}ms'
    assert 9.5 <= dur <= 10.5, f'bytes window duration {dur:.3f}s'
    kinds = set(b.keys()) - {'second', 'monotonic_ns', 'wall_ns'}
    payload = 0
    for k in kinds:
        payload += sum(y - x for x, y in zip(a[k], b[k]))
    dt = b['wall_ns'] - a['wall_ns']
    if dt <= 0 or payload <= 0:
        return None
    return payload * 8000 / dt


def payload_bytes(bytes_jsonl, begin_ns, end_ns):
    a, b, _, _, _ = window_samples(bytes_jsonl, begin_ns, end_ns)
    kinds = set(b.keys()) - {'second', 'monotonic_ns', 'wall_ns'}
    total = 0
    for k in kinds:
        total += sum(y - x for x, y in zip(a[k], b[k]))
    return total


def tx_bytes(phy_jsonl, begin_ns, end_ns):
    if len(phy_jsonl) < 2:
        return None
    a, b, sa, sb, dur = window_samples(phy_jsonl, begin_ns, end_ns)
    assert sa <= 50 and sb <= 50, f'phy sample skew {sa:.1f}ms / {sb:.1f}ms'
    assert 9.5 <= dur <= 10.5, f'phy window duration {dur:.3f}s'
    return b['tx_bytes'] - a['tx_bytes']


def parse_ping(path):
    if not path.exists():
        return []
    r = re.compile(r'^\[(\d+)\.(\d{6})\].*icmp_seq=(\d+).*time[=<]([\d.]+) ms')
    out = []
    for line in path.read_text().splitlines():
        m = r.search(line)
        if not m:
            continue
        sec, usec, seq, rtt = m.groups()
        wall_ns = int(sec) * 10**9 + int(usec) * 1000
        out.append({'wall_ns': wall_ns, 'seq': int(seq), 'rtt': float(rtt)})
    return out


def ping_stats(pings, begin_ns, end_ns):
    selected = [p for p in pings if begin_ns <= p['wall_ns'] <= end_ns]
    if not selected:
        return None, 0
    rtts = [p['rtt'] for p in selected]
    seqs = [p['seq'] for p in selected]
    p95 = sorted(rtts)[math.ceil(len(rtts) * 0.95) - 1]
    missing = max(seqs) - min(seqs) + 1 - len(set(seqs))
    return p95, missing


def load_qdisc(raw, side, label):
    (q,) = json.loads((raw / f'loss-{side}-{label}.json').read_text()); assert q['kind']=='netem'; return q



def loss_pct_between(raw, side, a, b):
    before,after=load_qdisc(raw,side,a),load_qdisc(raw,side,b)
    random=after.get('dropped',0)-before.get('dropped',0)
    offered=sum(after[k]-before[k] for k in ('packets','drops','qlen'))
    if offered <= 0:
        return 0.0
    return 100.0 * random / offered


def transition_latency(raw, event_name, direction):
    """Return ms between tc change and first counter increment in the relevant phase.

    auto_* fields are unsigned cumulative counters. We baseline the counter from
    the last hub sample before the tc change, then look for the first sample
    after the change whose counter is strictly greater, within the phase that
    follows the change.
    """
    log_path = raw / 'transition.log'
    if not log_path.exists():
        return None
    change_rec = None
    for line in log_path.read_text().splitlines():
        rec = json.loads(line)
        if rec.get('event') == event_name:
            change_rec = rec
            break
    if change_rec is None:
        return None
    change_ns = change_rec['monotonic_ns']

    stats = load_jsonl(raw / 'hub-stats.jsonl')
    if not stats:
        return None

    # Determine which counter to watch and which phase window bounds the search.
    if event_name == 'to_loss':
        key = 'auto_tx_on' if direction == 'down' else 'auto_rx_on'
        phase_end_key = 'phase2_end'
    elif event_name == 'to_clean':
        key = 'auto_tx_off' if direction == 'down' else 'auto_rx_off'
        phase_end_key = 'phase3_end'
    else:
        return None

    def counter_value(sample):
        data = sample.get('data', {})
        if key in data:
            return data[key]
        return data.get('awg_recovery', {}).get(key)

    # Find last sample before the tc change.
    before = None
    for s in stats:
        if s['monotonic_ns'] < change_ns:
            before = s
    if before is None:
        return None
    base = counter_value(before)
    if base is None:
        return None

    # Find phase end time from transition log snapshots.
    phase_end_ns = None
    for line in log_path.read_text().splitlines():
        rec = json.loads(line)
        if rec.get('event') == 'snapshot' and rec.get('label') == phase_end_key:
            phase_end_ns = rec['monotonic_ns']
            break
    if phase_end_ns is None:
        return None

    # First increment after the change, before phase end.
    for s in stats:
        if s['monotonic_ns'] <= change_ns:
            continue
        if s['monotonic_ns'] > phase_end_ns:
            break
        val = counter_value(s)
        if val is None:
            continue
        if val > base:
            lat = (s['monotonic_ns'] - change_ns) / 1e6
            return lat if lat >= 0 else None
    return None


def fmt(x):
    return f'{x:.3f}' if x is not None else '-'


def fmti(x):
    return str(int(x)) if x is not None else '-'


for log in map(Path, sys.argv[1:]):
    case = run = None
    for line in log.read_text().splitlines():
        if line.startswith('CASE '):
            assert case is None, case
            case = line.split()[1:]
        elif line.startswith('ARTIFACTS '):
            run = Path(line.split()[1]).name
        elif line == 'DONE':
            raw = log.parent / run / 'raw'
            arm, loss, seed, flows, rate, direction = case
            loss = int(loss)
            seed = int(seed)
            flows = int(flows)
            rate = int(rate)
            profile = load_profile(raw)
            bytes_jsonl = load_jsonl(raw / 'bytes.jsonl')
            hub_phy = load_jsonl(raw / 'phy-hub.jsonl')
            cli_phy = load_jsonl(raw / 'phy-client.jsonl')
            overlay = parse_ping(raw / 'overlay.ping')
            underlay = parse_ping(raw / 'underlay.ping')
            window = json.loads((raw / 'window.json').read_text())
            wb = window['begin_wall_ns']
            we = window['end_wall_ns']
            window_s = (we - wb) / 1e9

            if loss == 2:
                wins = phase_windows_wall(profile, wb)
                profile_name = 'transition'
            else:
                wins = single_window_wall(wb, round(window_s))
                profile_name = 'baseline-clean' if loss == 0 else 'baseline-loss'

            Mbps = {}
            payload = {}
            hub_tx = {}
            cli_tx = {}
            op95 = {}
            omiss = {}
            up95 = {}
            for name, (b, e) in wins.items():
                Mbps[name] = goodput(bytes_jsonl, b, e)
                payload[name] = payload_bytes(bytes_jsonl, b, e)
                hub_tx[name] = tx_bytes(hub_phy, b, e)
                cli_tx[name] = tx_bytes(cli_phy, b, e)
                op95[name], omiss[name] = ping_stats(overlay, b, e)
                up95[name], _ = ping_stats(underlay, b, e)

            ratios = {}
            for name in wins:
                wire = (hub_tx.get(name) or 0) + (cli_tx.get(name) or 0)
                pay = payload.get(name)
                if wire and pay:
                    ratios[name] = wire / pay
                else:
                    ratios[name] = None

            if loss == 2:
                to_loss_lat = transition_latency(raw, 'to_loss', direction)
                to_clean_lat = transition_latency(raw, 'to_clean', direction)
            else:
                to_loss_lat = to_clean_lat = None

            boundaries=[('init','phase1_end'),('to_loss','phase2_end'),('to_clean','phase3_end')] if loss==2 else [('init','final')]*3
            loss_rates=[fmt(loss_pct_between(raw,side,a,b)) for side in ('down','up') for a,b in boundaries]

            out.writerow([
                arm, loss, seed, flows, rate, direction, run, 'ok', profile_name, fmt(window_s),
                fmt(Mbps.get('clean1')), fmt(Mbps.get('loss')), fmt(Mbps.get('clean2')),
                fmti(hub_tx.get('clean1')), fmti(hub_tx.get('loss')), fmti(hub_tx.get('clean2')),
                fmti(cli_tx.get('clean1')), fmti(cli_tx.get('loss')), fmti(cli_tx.get('clean2')),
                fmti(payload.get('clean1')), fmti(payload.get('loss')), fmti(payload.get('clean2')),
                fmt(ratios.get('clean1')), fmt(ratios.get('loss')), fmt(ratios.get('clean2')),
                fmt(op95.get('clean1')), fmt(op95.get('loss')), fmt(op95.get('clean2')),
                fmti(omiss.get('loss')),
                fmt(up95.get('clean1')), fmt(up95.get('loss')), fmt(up95.get('clean2')),
                fmt(to_loss_lat), fmt(to_clean_lat),
                *loss_rates,
            ])
            case = run = None
        elif line == 'FAILED':
            out.writerow([*case, run, 'failed', *(['-'] * 32)])
            case = run = None
    assert case is None, case
