#!/usr/bin/env bash
set -eu -o pipefail
cd "$(dirname "$0")"
export LC_ALL=C LAB_OFFLOADS=selective LAB_HUB_CORES=0-3 LAB_CLIENT_CORES=4-5 LAB_IPERF_CORES=6-7 LAB_WARMUP_S=0 LAB_WINDOW_S=10
export LAB_CASES="$PWD/no-prime/final-cases.sh"
failed=0
read -r -a profiles <<< "$2"
for spec in "${profiles[@]}"; do
  IFS=: read -r build arm mode delay loss seed flows rate direction <<< "$spec"
  export LAB_BINARY_DIR="$PWD/$build" LAB_ARM="$arm" LAB_TRANSPORT="$mode" LAB_DELAY_MS="$delay" LAB_LOSS="$loss" LAB_SEED="$seed" LAB_FLOWS="$flows" LAB_RATE="$rate" LAB_DIRECTION="$direction"
  log="$1-$build-$mode-$delay.log"; printf 'CASE %s %s %s %s %s %s\n' "$arm" "$loss" "$seed" "$flows" "$rate" "$direction" | tee -a "$log"
  if ! unshare -Urn -- bash native.sh >>"$log" 2>&1; then echo FAILED >>"$log"; failed=1; fi
  python3 -I final-reduce.py "$log" | tail -1 | cut -f1-10,18,26
done
exit "$failed"
