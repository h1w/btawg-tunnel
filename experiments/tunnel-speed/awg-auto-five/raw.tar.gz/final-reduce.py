#!/usr/bin/env python3
"""Reducer for the final transparent-AWG profile suite.

Reads final.log (or any log produced by final.sh) and emits a TSV with one
row per completed/failed CASE. Throughput is computed from the receiver's
TCP_INFO bytes_received over the fixed post-warmup window.
"""
import csv
import json
import math
import re
import sys
from pathlib import Path

# Each log ends in the expected one-way delay; directional settings are
# persisted with the case so offline replay cannot silently assume symmetry.


def load(raw, stem):
    return [json.loads((raw / f'{stem}-{phase}.json').read_text()) for phase in ('before', 'after')]


def validate_path(raw, loss, seed, link, delay):
    for side, expected_seed in (('down', seed + 1000), ('up', seed)):
        profile = raw / 'profile.json'
        expected = json.loads(profile.read_text())[side] if profile.exists() else loss
        for qs in load(raw, f'loss-{side}'):
            q, = qs
            opts = q['options']
            assert q['kind'] == 'netem' and opts['limit'] == 262144
            assert abs(opts.get('delay', {}).get('delay', 0) - delay/1000) < .001
            assert opts.get('loss-random', {}).get('loss', 0) == expected / 100
            if expected:
                assert opts['seed'] == expected_seed
    for qs in load(raw, 'fifo'):
        if not link:
            assert not any(q['kind'] in ('tbf', 'bfifo') for q in qs)
            continue
        rate, = (q for q in qs if q['kind'] == 'tbf')
        fifo, = (q for q in qs if q['kind'] == 'bfifo')
        assert rate['root'] and rate['options']['rate'] == 1_250_000
        assert fifo['parent'] == rate['handle'] + '1' and fifo['options']['limit'] == 32_000


def qdelta(raw, stem, kind):
    before, after = [next(q for q in qs if q['kind'] == kind) for qs in load(raw, stem)]
    return after['drops'] - before['drops'], after.get('dropped', 0) - before.get('dropped', 0)


def delta_byte(begin, end, kind):
    if kind not in end:
        return '-'
    changes = [b - a for a, b in zip(begin[kind], end[kind], strict=True)]
    assert all(value >= 0 for value in changes)
    return f"{sum(changes)*8000/(end['monotonic_ns']-begin['monotonic_ns']):.3f}"


def ping_p95(raw, start, end, filename='underlay.ping'):
    rtts = []
    for line in (raw / filename).read_text().splitlines():
        m = re.search(r'^\[(\d+)\.(\d{6})\].*time[=<]([\d.]+) ms', line)
        if m and start <= int(m[1])*10**9 + int(m[2])*1000 <= end:
            rtts.append(float(m[3]))
    assert rtts, raw
    return f'{sorted(rtts)[math.ceil(len(rtts)*.95)-1]:.1f}', len(rtts)


def rcv_errors(raw, side):
    values = []
    for phase in ('before', 'after'):
        keys, vals = [line.split()[1:] for line in (raw / f'{side}-net-{phase}').read_text().splitlines() if line.startswith('Udp:')]
        values.append(int(dict(zip(keys, vals, strict=True))['RcvbufErrors']))
    return values[1] - values[0]


def phy_delta(raw, side):
    data = json.loads((raw / f'phy-{side}.json').read_text())
    begin, end = data['begin'], data['end']
    return {
        'begin': begin,
        'end': end,
        'tx_bytes': end['tx_bytes'] - begin['tx_bytes'],
        'tx_packets': end['tx_packets'] - begin['tx_packets'],
        'tx_dropped': end['tx_dropped'] - begin['tx_dropped'],
        'duration_s': data['duration_s'],
        'begin_skew_ms': begin['skew_ms'],
        'end_skew_ms': end['skew_ms'],
    }


def netem_loss(raw, side):
    before, after = load(raw, f'loss-{side}')
    q, = (q for q in after if q['kind'] == 'netem')
    p, = (q for q in before if q['kind'] == 'netem')
    drops = q['drops'] - p['drops']
    random = q.get('dropped', 0) - p.get('dropped', 0)
    offered = drops + (q['packets'] - p['packets']) + (q.get('qlen', 0) - p.get('qlen', 0))
    return random, offered


def useful_bytes(begin, end):
    total = 0
    for key in set(end.keys()) - {'second', 'monotonic_ns', 'wall_ns'}:
        total += sum(b - a for a, b in zip(begin[key], end[key], strict=True))
    return total


out = csv.writer(sys.stdout, delimiter='\t', lineterminator='\n')
out.writerow('arm loss seed tunnel_flows link_Mbps direction run status tunnel_Mbps direct_Mbps rtt_p95_ms rtt_replies fifo_drops random_drops excess_netem engine_drops udp_rcv_errors overlay_p95_ms overlay_n hub_tx_bytes hub_tx_packets cli_tx_bytes cli_tx_packets wire_bytes payload_bytes wire_ratio down_loss_pct up_loss_pct window_s hub_parity_blocks hub_recovered hub_control_bytes hub_expired_controls'.split())

for log in map(Path, sys.argv[1:]):
    case = run = None
    for line in log.read_text().splitlines():
        if line.startswith('CASE '):
            assert case is None, case
            case = line.split()[1:]
        elif line.startswith('ARTIFACTS '):
            run = Path(line.split()[1]).name
        elif line == 'DONE':
            raw = log.parent / run / 'raw'
            arm, loss, seed, flows, link, direction = case
            link = int(link)
            loss = int(loss)
            seed = int(seed)
            flows = int(flows)
            validate_path(raw, loss, seed, link, int(log.stem.rsplit('-', 1)[1]))
            samples = [json.loads(ln) for ln in (raw / 'bytes.jsonl').read_text().splitlines()]
            assert [s['second'] for s in samples] == list(range(11))
            begin = samples[0]
            if 'tunnel' in begin: assert not any(begin['tunnel']), 'TCP payload preceded the cold window'
            end = samples[-1]
            window = (end['monotonic_ns'] - begin['monotonic_ns']) / 1e9
            assert 9.95 < window < 10.05, window
            kinds = {'direct': 1} if link else {}
            if arm != 'tcp':
                kinds['tunnel'] = flows
            for moment in samples:
                assert set(moment) - {'second', 'monotonic_ns', 'wall_ns'} == kinds.keys()
                assert all(len(moment[k]) == v for k, v in kinds.items())
            p95, n = ping_p95(raw, begin['wall_ns'], end['wall_ns'])
            total, random = [sum(x) for x in zip(*(qdelta(raw, f'loss-{side}', 'netem') for side in ('down', 'up')), strict=True)]
            assert total >= random
            fifo = qdelta(raw, 'fifo', 'bfifo')[0] if link else 0
            before, after = load(raw, 'engine')
            mode = log.stem.split('-socks5-',1)[1].rsplit('-',1)[0]; mode = 'socks5-'+mode
            row = [delta_byte(begin, end, t) for t in ('tunnel', 'direct')]
            if arm == 'tcp':
                overlay, overlay_n = '-', 0
            else:
                overlay, overlay_n = ping_p95(raw, begin['wall_ns'], end['wall_ns'], 'overlay.ping')
                overlay_n = int(overlay_n)
            ra, rb = load(raw, 'recovery')
            recovery = [rb[k]-ra[k] for k in ('parity_blocks','recovered_packets','control_bytes','expired_controls')]
            assert all(v>=0 for v in recovery)
            if arm not in ('reserve','wide','coded','auto'): assert not any(recovery), (case, recovery)
            hub_phy = phy_delta(raw, 'hub')
            cli_phy = phy_delta(raw, 'client')
            assert hub_phy['tx_bytes'] > 0 and hub_phy['tx_packets'] > 0
            assert cli_phy['tx_bytes'] > 0 and cli_phy['tx_packets'] > 0
            assert hub_phy['begin_skew_ms'] <= 50 and hub_phy['end_skew_ms'] <= 50
            assert cli_phy['begin_skew_ms'] <= 50 and cli_phy['end_skew_ms'] <= 50
            # Enforce physical samples align with the receiver's actual window.
            window_ns = end['monotonic_ns'] - begin['monotonic_ns']
            for phy in (hub_phy, cli_phy):
                assert abs(phy['begin']['monotonic_ns'] - begin['monotonic_ns']) <= 50_000_000
                assert abs(phy['end']['monotonic_ns'] - end['monotonic_ns']) <= 50_000_000
                assert abs((phy['end']['monotonic_ns'] - phy['begin']['monotonic_ns']) - window_ns) <= 50_000_000
            wire_bytes = hub_phy['tx_bytes'] + cli_phy['tx_bytes']
            payload_bytes = useful_bytes(begin, end)
            assert payload_bytes > 0
            ratio = wire_bytes / payload_bytes
            # Wire must include at least the payload; a lower value means a
            # measurement mismatch or negative-cost accounting.
            if arm != 'tcp' and link == 0:
                assert ratio >= 1.0, ratio
            wire_ratio = f'{ratio:.3f}'
            down_random, down_offered = netem_loss(raw, 'down')
            up_random, up_offered = netem_loss(raw, 'up')
            down_loss_pct = f'{100 * down_random / down_offered:.3f}' if down_offered else '0.000'
            up_loss_pct = f'{100 * up_random / up_offered:.3f}' if up_offered else '0.000'
            out.writerow([*case, run, 'ok', *row, p95, n, fifo, random, total-random, after.get(mode, 0)-before.get(mode, 0), sum(rcv_errors(raw, s) for s in ('hub', 'client')), overlay, overlay_n, hub_phy['tx_bytes'], hub_phy['tx_packets'], cli_phy['tx_bytes'], cli_phy['tx_packets'], wire_bytes, payload_bytes, wire_ratio, down_loss_pct, up_loss_pct, f'{window:.3f}', *recovery])
            case = run = None
        elif line == 'FAILED':
            out.writerow([*case, run, 'failed', *(['-']*25)])
            case = run = None
    assert case is None, case
