#!/usr/bin/env python3
"""Direction-aware TCP workload generator/receiver for the AWG integrated lab.

Usage:
    final-traffic.py send    <direction> <kind>
    final-traffic.py receive <direction> <active-kinds>

<direction> is 'up' or 'down' and describes the tunnel traffic direction.
The direct (shared-downlink) flow is always server->client regardless of
<direction> because the shared bottleneck is the client downlink.

<kind> is 'tunnel' or 'direct'.
<active-kinds> is a comma-separated list, e.g. 'tunnel' or 'direct,tunnel'.
"""
import json
import os
import socket
import struct
import sys
import threading
import time
from pathlib import Path

DIRECTION = sys.argv[2]
KIND = sys.argv[3] if sys.argv[1] == 'send' else None
ACTIVE = sys.argv[3].split(',') if sys.argv[1] == 'receive' else []

FLOWS = int(os.environ['LAB_FLOWS'])
SERVER_VPN = '10.77.0.1'
CLIENT_DIRECT = '192.0.2.6'
SERVER_DIRECT = '192.0.2.1'
CLIENT_IP = os.environ.get('LAB_CLIENT_IP', CLIENT_DIRECT)


def flow_cfg(kind):
    # Listener and connector use the same overlay/underlay address; both are
    # reachable from their respective namespaces through the shared routing.
    direction = 'down' if kind == 'direct' else DIRECTION
    if kind == 'direct':
        addr, port, count = SERVER_DIRECT, 5202, 1
    elif direction == 'down':
        addr, port, count = SERVER_VPN, 5201, FLOWS
    else:
        addr, port, count = CLIENT_IP, 5201, FLOWS
    return {'listen': addr, 'connect': addr, 'port': port, 'count': count}

WARMUP = float(os.environ.get('LAB_WARMUP_S', '2'))
WINDOW = int(os.environ.get('LAB_WINDOW_S', '10'))
SAMPLES = range(WINDOW + 1)

SENDER_SAMPLE_INTERVAL_NS = 250_000_000

block = bytes(128 << 10)


def wait_for(name):
    until = time.monotonic() + 50
    path = Path(name)
    while True:
        try:
            return path.read_text()
        except FileNotFoundError:
            if time.monotonic() >= until:
                raise TimeoutError(name)
            time.sleep(0.02)


def stamp(name, value=''):
    path = Path(name)
    tmp = path.with_suffix('.tmp')
    tmp.write_text(value)
    tmp.rename(path)


def pump(sock, send):
    try:
        if send:
            while True:
                sock.sendall(block)
        else:
            buf = bytearray(len(block))
            while sock.recv_into(buf):
                pass
    finally:
        sock.close()


def listen(kind, addr, port, count):
    with socket.socket() as s:
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        s.setsockopt(socket.IPPROTO_TCP, socket.TCP_CONGESTION, b'cubic')
        s.bind((addr, port))
        s.listen(count)
        s.settimeout(30)
        stamp(f'{kind}-ready')
        conns = [s.accept()[0] for _ in range(count)]
    for conn in conns:
        assert conn.getsockopt(socket.IPPROTO_TCP, socket.TCP_CONGESTION, 16).rstrip(b'\0') == b'cubic'
    return conns


def start(conns, send):
    for conn in conns:
        threading.Thread(target=pump, args=(conn, send), daemon=True).start()


def bytes_received(conn):
    info = conn.getsockopt(socket.IPPROTO_TCP, socket.TCP_INFO, 256)
    return struct.unpack_from('=Q', info, 128)[0]


def tcp_info_counts(conn):
    """Return integer counts only (no rates) from TCP_INFO."""
    info = conn.getsockopt(socket.IPPROTO_TCP, socket.TCP_INFO, 256)
    return {
        'cwnd': struct.unpack_from('=I', info, 80)[0],
        'mss': struct.unpack_from('=I', info, 16)[0],
        'rtt_us': struct.unpack_from('=I', info, 68)[0],
        'retrans': struct.unpack_from('=I', info, 100)[0],
        'acked': struct.unpack_from('=Q', info, 120)[0],
        'snd_wnd': struct.unpack_from('=I', info, 228)[0],
        'rwnd_limited_us': struct.unpack_from('=Q', info, 176)[0],
    }


def sample_sender(conns, start_path, done_path, out_path):
    """Snapshot sender-side TCP_INFO every ~250 ms after the receiver start."""
    start = Path(start_path)
    done = Path(done_path)
    out = Path(out_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    deadline = time.monotonic() + 60
    while not start.exists():
        if done.exists() or time.monotonic() > deadline:
            return
        time.sleep(0.02)
    try:
        start_ns = int(start.read_text())
    except Exception:
        return
    with out.open('w') as f:
        i = 0
        while True:
            target = start_ns + i * SENDER_SAMPLE_INTERVAL_NS
            now = time.monotonic_ns()
            if target > now:
                time.sleep(min((target - now) / 1e9, 0.05))
                if done.exists():
                    break
                continue
            if done.exists():
                break
            sample = {
                'monotonic_ns': time.monotonic_ns(),
                'wall_ns': time.time_ns(),
                'flows': [tcp_info_counts(conn) for conn in conns],
            }
            f.write(json.dumps(sample) + '\n')
            f.flush()
            i += 1


if sys.argv[1] == 'send':
    cfg = flow_cfg(KIND)
    conns = listen(KIND, cfg['listen'], cfg['port'], cfg['count'])
    if KIND == 'tunnel':
        wait_for('start')
    start(conns, True)
    threading.Thread(
        target=sample_sender,
        args=(conns, 'start', 'done', f'raw/tcpinfo-{KIND}.jsonl'),
        daemon=True,
    ).start()
    wait_for('done')
else:
    received = {}
    for kind in ACTIVE:
        cfg = flow_cfg(kind)
        wait_for(f'{kind}-ready')
        conns = [socket.create_connection((cfg['connect'], cfg['port']), timeout=12) for _ in range(cfg['count'])]
        for conn in conns:
            conn.setblocking(True)
        start(conns, False)
        received[kind] = conns
        if kind == 'direct':
            # Let the shared direct CUBIC flow establish before admitting tunnel.
            time.sleep(2)
    start_ns = time.monotonic_ns()
    start_wall_ns = time.time_ns()
    rows = []
    window_begin_ns = window_end_ns = None
    for second in SAMPLES:
        target = start_ns + int(second * 1e9)
        now = time.monotonic_ns()
        if target > now:
            time.sleep((target - now) / 1e9)
        row = {'second': second, 'monotonic_ns': time.monotonic_ns(), 'wall_ns': time.time_ns()}
        for kind, conns in received.items():
            row[kind] = [bytes_received(conn) for conn in conns]
        rows.append(row)
        print(json.dumps(row), flush=True)
        if second == WARMUP:
            window_begin_ns = row['monotonic_ns']
            stamp('window-begin', str(window_begin_ns))
            stamp('start', str(window_begin_ns))  # release tunnel senders only after the zero-byte sample
        if second == WARMUP + WINDOW:
            window_end_ns = row['monotonic_ns']
            stamp('window-end', str(window_end_ns))
    end_ns = time.monotonic_ns()
    end_wall_ns = time.time_ns()
    stamp('done', str(end_ns))
    window = {
        'begin_monotonic_ns': window_begin_ns if window_begin_ns is not None else start_ns,
        'begin_wall_ns': start_wall_ns,
        'end_monotonic_ns': window_end_ns if window_end_ns is not None else end_ns,
        'end_wall_ns': end_wall_ns,
        'duration_s': ((window_end_ns if window_end_ns is not None else end_ns) -
                       (window_begin_ns if window_begin_ns is not None else start_ns)) / 1e9,
    }
    Path('raw/window.json').write_text(json.dumps(window, separators=(',', ':')))
