# Sourced inside native.sh for the AWG auto-repair transition profile suite.
#
# Environment expected from the runner:
#   LAB_ARM, LAB_LOSS, LAB_SEED, LAB_FLOWS, LAB_DIRECTION
#   LAB_DELAY_MS (default 100), LAB_OFFLOADS (selective)
#   LAB_PHASE_CLEAN1_S (default 12), LAB_PHASE_LOSS_S (default 32),
#   LAB_PHASE_CLEAN2_S (default 20), LAB_WARMUP_S (default 2)
#
# LAB_LOSS semantics:
#   0 = constant clean baseline
#   1 = constant 1%% loss baseline
#   2 = clean -> 1%% loss -> clean transition

set -euo pipefail

if [[ ${LAB_OFFLOADS:-selective} != selective ]]; then
  printf 'transition-cases only supports selective offloads\n' >&2
  exit 2
fi

case ${LAB_LOSS:-2} in
  0|1|2) : ;;
  *) printf 'LAB_LOSS must be 0 (clean baseline), 1 (loss baseline), or 2 (transition)\n' >&2; exit 2 ;;
esac

phase_clean1=${LAB_PHASE_CLEAN1_S:-12}
phase_loss=${LAB_PHASE_LOSS_S:-32}
phase_clean2=${LAB_PHASE_CLEAN2_S:-20}
warmup=${LAB_WARMUP_S:-2}
total_window=$((phase_clean1 + phase_loss + phase_clean2))
export LAB_TRANSITION_WINDOW_S="$total_window"

printf 'TRANSITION_PROFILE loss=%s phases=%s/%s/%s total_window=%ss warmup=%ss\n' \
  "${LAB_LOSS:-2}" "$phase_clean1" "$phase_loss" "$phase_clean2" "$total_window" "$warmup"

turn_off_tcp() {
  PYTHONPATH="$BIN" python3 - "$1" <<'PY'
import sys
from importlib import import_module
with import_module('offload-loss').Ethtool(sys.argv[1]) as eth:
    problems = eth.enforce_off(('tx-tcp-segmentation', 'tx-tcp-ecn-segmentation',
                                'tx-tcp-mangleid-segmentation', 'tx-tcp6-segmentation', 'rx-gro'))
    if problems:
        raise RuntimeError(problems)
PY
}

turn_off_tcp hub0
export -f turn_off_tcp
export BIN
cli bash -ec 'turn_off_tcp cli0'
wan bash -ec 'turn_off_tcp tohub; turn_off_tcp downloss'
fifo bash -ec 'turn_off_tcp fromwan; turn_off_tcp tocli'

delay_ms=${LAB_DELAY_MS:-100}
seed=${LAB_SEED:-101}
down_seed=$((seed + 1000))

# Initial netem: clean for transition/clean-baseline, lossy for loss-baseline.
initial_loss=0
if [[ ${LAB_LOSS:-2} == 1 ]]; then initial_loss=1; fi

if [[ $initial_loss == 0 ]]; then
  wan tc qdisc replace dev downloss root netem limit 262144 delay "${delay_ms}ms"
  wan tc qdisc replace dev tohub root netem limit 262144 delay "${delay_ms}ms"
else
  wan tc qdisc replace dev downloss root netem limit 262144 delay "${delay_ms}ms" loss random "1%" seed "$down_seed"
  wan tc qdisc replace dev tohub root netem limit 262144 delay "${delay_ms}ms" loss random "1%" seed "$seed"
fi

python3 - "$phase_clean1" "$phase_loss" "$phase_clean2" "$warmup" "$delay_ms" "$seed" "${LAB_LOSS:-2}" <<'PY'
import json, sys
c1, lo, c2, warmup, delay, seed, loss = sys.argv[1:8]
json.dump({
    'loss_profile': int(loss),
    'phase_clean1_s': int(c1),
    'phase_loss_s': int(lo),
    'phase_clean2_s': int(c2),
    'warmup_s': int(warmup),
    'delay_ms': int(delay),
    'seed': int(seed),
}, open('raw/profile.json', 'w'))
PY

# No shared direct downlink in the transition profile.
active=tunnel

if [[ $LAB_ARM == tcp ]]; then active=direct; fi

# Start the AWG client if this run uses the tunnel.
if [[ $active == *tunnel* ]]; then
  case $LAB_ARM in
    shim) repair=0;;
    reserve) repair=1;;
    wide) repair=wide;;
    coded) repair=coded;;
    auto) repair=auto;;
    *) exit 2;;
  esac
  nsenter -t "$child" -n -- env BTAWG_AWG_REPAIR="$repair" "${client_command[@]}" "$LAB_BINARY_DIR/btawg-client" -config client.txt -transport socks5-awg-udp >client.log 2>&1 & client=$!
  for ((i=0;i<15;i++)); do
    if cli ping -n -I btawg0 -c 1 -W 1 10.77.0.1 >>raw/start.ping 2>&1; then break; fi
    kill -0 "$client"
    [[ $i != 14 ]]
    sleep .2
  done
  client_ip=$(cli ip -brief -4 address show dev btawg0 | awk '{print $3}' | cut -d/ -f1)
  [[ -n "$client_ip" ]]
  printf 'CLIENT_IP %s\n' "$client_ip" >>raw/stages.txt
  export LAB_CLIENT_IP="$client_ip"
fi

verify_mtu() {
  local src_ns=$1 dst_ip=$2 label=$3
  if [[ $src_ns == cli ]]; then
    cli ping -n -M do -s 1252 -c 3 -I btawg0 "$dst_ip" >"raw/mtu-${label}.ping" 2>&1
  else
    ping -n -M do -s 1252 -c 3 -I btawg0 "$dst_ip" >"raw/mtu-${label}.ping" 2>&1
  fi
  if grep -qiE 'frag needed|too long|packet too big' "raw/mtu-${label}.ping"; then
    printf 'MTU %s FAILED\n' "$label" >&2
    cat "raw/mtu-${label}.ping" >&2
    exit 1
  fi
  printf 'MTU %s OK\n' "$label" >>raw/stages.txt
}

if [[ $active == *tunnel* ]]; then
  if [[ ${LAB_DIRECTION:-down} == down ]]; then
    verify_mtu hub "$client_ip" down
    verify_mtu cli 10.77.0.1 up
  else
    verify_mtu cli 10.77.0.1 up
    verify_mtu hub "$client_ip" down
  fi
fi

snapshot() {
  wan tc -s -j qdisc show dev downloss >"raw/loss-down-$1.json"
  wan tc -s -j qdisc show dev tohub >"raw/loss-up-$1.json"
  fifo tc -s -j qdisc show dev tocli >"raw/fifo-$1.json"
  curl -fs -m 3 -b cookies "$base/api/traffic" > "raw/traffic-$1.json"
  jq -e '.engine_queue_drops' "raw/traffic-$1.json" >"raw/engine-$1.json"
  jq -e '.awg_recovery' "raw/traffic-$1.json" >"raw/recovery-$1.json"
  cat /proc/net/snmp >"raw/hub-net-$1"
  cli cat /proc/net/snmp >"raw/client-net-$1"
  if [[ -e /sys/class/net/btawg0 ]]; then
    ip -s -j link show dev btawg0 >"raw/tun-hub-$1.json"
  else
    echo '[]' >"raw/tun-hub-$1.json"
  fi
  if cli test -e /sys/class/net/btawg0; then
    cli ip -s -j link show dev btawg0 >"raw/tun-client-$1.json"
  else
    echo '[]' >"raw/tun-client-$1.json"
  fi
}

snapshot init

# Continuous physical-interface sampler (any steady window can be extracted
# from these traces). Runs in the namespace that owns the interface.
python3 "$BIN/transition-phy.py" hub0 raw/phy-hub.jsonl & phy_hub=$!
cli python3 "$BIN/transition-phy.py" cli0 raw/phy-client.jsonl & phy_client=$!

ping -n -D -i .25 192.0.2.6 >raw/underlay.ping & underlay_ping=$!

# Hub auto-repair stats polled at 4 Hz; transition reducer extracts
# auto_tx_on/off (download) or auto_rx_on/off (upload) when available.
python3 "$BIN/transition-stats.py" "$base" cookies raw/hub-stats.jsonl & hub_stats=$!

if [[ $active == *tunnel* ]]; then
  if [[ ${LAB_DIRECTION:-down} == down ]]; then
    "${perf_command[@]}" python3 "$BIN/transition-traffic.py" send down tunnel 2>raw/tunnel.stderr & iperf=$!
  else
    cli "${perf_command[@]}" python3 "$BIN/transition-traffic.py" send up tunnel 2>raw/tunnel.stderr & iperf=$!
  fi
  nsenter -t "$child" -n -- ping -n -D -I btawg0 -i .25 10.77.0.1 >raw/overlay.ping & overlay_ping=$!
fi

# Start the transition scheduler once the receiver has opened its window.
if [[ ${LAB_LOSS:-2} == 2 ]]; then
  (
    export LAB_TRANSIT_PID="$transit" LAB_CHILD_PID="$child" LAB_LIMITER_PID="$limiter"
    python3 "$BIN/transition-scheduler.py" raw/transition.log
  ) & loss_sched=$!
fi

if [[ ${LAB_DIRECTION:-down} == down ]]; then
  cli timeout -k 2 120 "${perf_command[@]}" python3 "$BIN/transition-traffic.py" receive down "$active" >raw/bytes.jsonl 2>raw/receive.stderr
else
  timeout -k 2 120 "${perf_command[@]}" python3 "$BIN/transition-traffic.py" receive up "$active" >raw/bytes.jsonl 2>raw/receive.stderr
fi

if [[ -n ${direct:-} ]]; then wait "$direct"; direct=; fi
if [[ -n ${iperf:-} ]]; then wait "$iperf"; iperf=; fi

# Samplers stop automatically when 'done' appears.
if [[ -n ${phy_hub:-} ]]; then wait "$phy_hub"; phy_hub=; fi
if [[ -n ${phy_client:-} ]]; then wait "$phy_client"; phy_client=; fi
if [[ -n ${hub_stats:-} ]]; then wait "$hub_stats"; hub_stats=; fi
if [[ -n ${loss_sched:-} ]]; then wait "$loss_sched"; loss_sched=; fi

snapshot final
printf 'DONE\n'
