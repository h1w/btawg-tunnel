#!/usr/bin/env python3
"""Selective veth offload controls for lossy transit calibration.

This helper deliberately changes only the ethtool features needed to make
netem loss act on individual UDP datagrams:

  endpoint IFACE          tx-udp-segmentation=off
      Force UDP_SEGMENT super-packets to be split in software on the sending
      endpoint's veth, before transit netem can enqueue/drop them.  TCP GSO,
      TSO, TUN offloads, rx GRO, tx-gso-list (socket batching) and checksums
      are left untouched.

  transit IFACE [IFACE…]  rx-udp-gro-forwarding=off rx-gro-list=off
      Guard the forwarding namespace against rebuilding individual UDP
      datagrams into a GSO/fraglist skb before netem on its egress.  Generic
      GRO is not touched; all unrelated features stay as-is.  On veth these
      UDP GRO features are already off, so this is idempotent.

  show IFACE [IFACE…]     Report feature state (idempotent verification).

The ioctls are SIOCETHTOOL/ETHTOOL_GFEATURES and ETHTOOL_SFEATURES; no
`ethtool` binary or host configuration is required.  Run this inside the
target network namespace (e.g. via `nsenter -t <pid> -n -- python3 …`).

Runner integration (native.sh PID names):
  OL=/tmp/btawg-speed.qr4qO9oy/offload-loss.py
  python3 "$OL" endpoint hub0
  nsenter -t "$transit" -n -- python3 "$OL" transit tohub tocli
  nsenter -t "$child"   -n -- python3 "$OL" endpoint cli0

If each namespace also has its own user namespace, add `-U` to `nsenter`.
"""

from __future__ import annotations

import argparse
import ctypes as c
import os
import socket
import sys

SIOCETHTOOL = 0x8946
ETH_SS_FEATURES = 4
ETHTOOL_GSTRINGS = 0x1B
ETHTOOL_GSSET_INFO = 0x37
ETHTOOL_GFEATURES = 0x3A
ETHTOOL_SFEATURES = 0x3B

ENDPOINT_OFF = ("tx-udp-segmentation",)
TRANSIT_OFF = ("rx-udp-gro-forwarding", "rx-gro-list")
REPORT = ENDPOINT_OFF + TRANSIT_OFF + (
    "tx-generic-segmentation",
    "generic-segmentation-offload",
    "tx-tcp-segmentation",
    "tcp-segmentation-offload",
    "rx-gro",
    "generic-receive-offload",
    "tx-gso-list",
    "tx-checksum-ip-generic",
)


class IfReq(c.Structure):
    _fields_ = [
        ("name", c.c_char * 16),
        ("data", c.c_void_p),
        ("pad", c.c_byte * 16),
    ]


class Ethtool:
    def __init__(self, ifname: str):
        self.ifname = ifname
        encoded = ifname.encode()
        if len(encoded) > 15:
            raise ValueError(f"interface name too long: {ifname!r}")
        self._req = IfReq(encoded, 0)
        self._libc = c.CDLL(None, use_errno=True)
        self._sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.names: list[str] = []
        self.get_buf: c.Array[c.c_uint32] | None = None
        self._load()

    def close(self) -> None:
        self._sock.close()

    def __enter__(self) -> Ethtool:
        return self

    def __exit__(self, *_exc: object) -> None:
        self.close()

    def _ioctl(self, buf: c.Array[c.c_uint32]) -> None:
        self._req.data = c.addressof(buf)
        c.set_errno(0)
        if self._libc.ioctl(self._sock.fileno(), c.c_ulong(SIOCETHTOOL), c.byref(self._req)) < 0:
            err = c.get_errno()
            raise OSError(err, f"ethtool ioctl on {self.ifname!r}: {os.strerror(err)}")

    def _load(self) -> None:
        info = (c.c_uint32 * 5)(ETHTOOL_GSSET_INFO, 0, 1 << ETH_SS_FEATURES, 0, 0)
        self._ioctl(info)
        count = info[4]
        if count == 0:
            raise RuntimeError(f"no ethtool features on {self.ifname!r}")

        strings = (c.c_uint32 * (3 + count * 8))(ETHTOOL_GSTRINGS, ETH_SS_FEATURES, count)
        self._ioctl(strings)
        self.names = [
            c.string_at(c.addressof(strings) + 12 + i * 32, 32).split(b"\0", 1)[0].decode(errors="replace")
            for i in range(count)
        ]
        words = (count + 31) // 32
        self.get_buf = (c.c_uint32 * (2 + words * 4))(ETHTOOL_GFEATURES, words)
        self._ioctl(self.get_buf)
        if self.get_buf[1] != words:
            raise RuntimeError(f"unexpected feature word count on {self.ifname!r}")

    def refresh(self) -> None:
        assert self.get_buf is not None
        self._ioctl(self.get_buf)

    def find(self, name: str) -> int | None:
        try:
            return self.names.index(name)
        except ValueError:
            return None

    def active(self, name: str) -> bool | None:
        idx = self.find(name)
        if idx is None or self.get_buf is None:
            return None
        word, bit = divmod(idx, 32)
        return bool(self.get_buf[4 + word * 4] & (1 << bit))

    def available(self, name: str) -> bool | None:
        idx = self.find(name)
        if idx is None or self.get_buf is None:
            return None
        word, bit = divmod(idx, 32)
        return bool(self.get_buf[2 + word * 4] & (1 << bit))

    def never_changed(self, name: str) -> bool | None:
        idx = self.find(name)
        if idx is None or self.get_buf is None:
            return None
        word, bit = divmod(idx, 32)
        return bool(self.get_buf[5 + word * 4] & (1 << bit))

    def requested(self, name: str) -> bool | None:
        idx = self.find(name)
        if idx is None or self.get_buf is None:
            return None
        word, bit = divmod(idx, 32)
        return bool(self.get_buf[3 + word * 4] & (1 << bit))

    def set_features(self, desired: dict[str, bool]) -> None:
        """Change named features only; keep all other requested bits intact."""
        assert self.get_buf is not None
        words = self.get_buf[1]
        req = (c.c_uint32 * (2 + words * 2))(ETHTOOL_SFEATURES, words)
        touched = 0
        for name, value in desired.items():
            idx = self.find(name)
            if idx is None:
                # A feature absent from this device cannot be active; no-op.
                continue
            word, bit = divmod(idx, 32)
            req[2 + word * 2] |= 1 << bit  # valid mask: only this bit
            if value:
                req[3 + word * 2] |= 1 << bit  # requested value
            touched += 1
        if touched == 0:
            return
        self._ioctl(req)
        self.refresh()

    def enforce_off(self, names: tuple[str, ...]) -> list[str]:
        problems: list[str] = []
        desired: dict[str, bool] = {}
        for name in names:
            idx = self.find(name)
            if idx is None:
                continue
            if self.active(name) or (self.available(name) and not self.never_changed(name)):
                # Clear the requested bit too, so a later renegotiation cannot
                # silently re-enable the feature (other requested bits stay).
                desired[name] = False
        self.set_features(desired)
        for name in names:
            if self.active(name):
                problems.append(f"{self.ifname}: {name} still active")
        return problems


def fmt(value: bool | None) -> str:
    if value is None:
        return "n/a"
    return "on" if value else "off"


def show(et: Ethtool, all_features: bool) -> None:
    names = et.names if all_features else [n for n in REPORT if et.find(n) is not None]
    for name in names:
        if not name:
            continue
        print(
            f"{et.ifname} {name} active={fmt(et.active(name))} "
            f"requested={fmt(et.requested(name))} available={fmt(et.available(name))} "
            f"never_changed={fmt(et.never_changed(name))}"
        )


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = parser.add_subparsers(dest="command", required=True)

    p_show = sub.add_parser("show", help="show selected (or --all) feature states")
    p_show.add_argument("ifaces", metavar="IFACE", nargs="+")
    p_show.add_argument("--all", action="store_true", dest="all_features")

    p_endpoint = sub.add_parser("endpoint", help="force software UDP segmentation on sender veth")
    p_endpoint.add_argument("iface", metavar="IFACE")

    p_transit = sub.add_parser("transit", help="stop GRO re-coalescing forwarded UDP before netem")
    p_transit.add_argument("ifaces", metavar="IFACE", nargs="+")

    args = parser.parse_args(argv)
    problems: list[str] = []
    ifaces = args.ifaces if args.command in ("show", "transit") else [args.iface]
    try:
        for ifname in ifaces:
            with Ethtool(ifname) as et:
                if args.command == "show":
                    show(et, args.all_features)
                elif args.command == "endpoint":
                    problems.extend(et.enforce_off(ENDPOINT_OFF))
                    show(et, all_features=False)
                elif args.command == "transit":
                    problems.extend(et.enforce_off(TRANSIT_OFF))
                    show(et, all_features=False)
    except (OSError, RuntimeError, ValueError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2
    if problems:
        for problem in problems:
            print(f"error: {problem}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
